from random import*
import time
print("")

print("   COPYRIGHT 2022-2023")
time.sleep(0.4)
print("   CREATED BY : THE GUY ")
time.sleep(0.4)











print("                  ██████╗░░█████╗░░██████╗░██████╗░██╗░░░░░░░██╗░█████╗░██████╗░██████╗░")
print("                  ██╔══██╗██╔══██╗██╔════╝██╔════╝░██║░░██╗░░██║██╔══██╗██╔══██╗██╔══██╗")
print("                  ██╔══██╗██╔══██╗██╔════╝██╔════╝░██║░░██╗░░██║██╔══██╗██╔══██╗██╔══██╗")
print("                  ██████╔╝███████║╚█████╗░╚█████╗░░╚██╗████╗██╔╝██║░░██║██████╔╝██║░░██║")
print("                  ██╔═══╝░██╔══██║░╚═══██╗░╚═══██╗░░████╔═████║░██║░░██║██╔══██╗██║░░██║")
print("                  ██║░░░░░██║░░██║██████╔╝██████╔╝░░╚██╔╝░╚██╔╝░╚█████╔╝██║░░██║██████╔╝")
print("                  ╚═╝░░░░░╚═╝░░╚═╝╚═════╝░╚═════╝░░░░╚═╝░░░╚═╝░░░╚════╝░╚═╝░░╚═╝╚═════╝░")
print("    ")
print("                        ░██████╗░███████╗███╗░░██╗███████╗██████╗░░█████╗░████████╗░█████╗░██████╗░")
print("                        ██╔════╝░██╔════╝████╗░██║██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗")
print("                        ██║░░██╗░█████╗░░██╔██╗██║█████╗░░██████╔╝███████║░░░██║░░░██║░░██║██████╔╝")
print("                        ██║░░╚██╗██╔══╝░░██║╚████║██╔══╝░░██╔══██╗██╔══██║░░░██║░░░██║░░██║██╔══██╗")
print("                        ╚██████╔╝███████╗██║░╚███║███████╗██║░░██║██║░░██║░░░██║░░░╚█████╔╝██║░░██║")
print("                        ░╚═════╝░╚══════╝╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝")

n=int(input("Set your password long "))
p=""



    
for i in range(n):
    k=randint(1,26)
    
    print("\r   LOADING",end="")
    
    
    time.sleep(0.2)
    if k == 1:
        r=randint(1,2)
        if r == 1:
            p+="A" 
        else:
            p+="a"
    elif k == 2:
        r=randint(1,2)
        if r == 1:
            p+="B" 
        else:
            p+="b"
    elif k == 3:
        r=randint(1,2)
        if r == 1:
            p+="C" 
        else:
            p+="c"    
    elif k == 4:
        r=randint(1,2)
        if r == 1:
            p+="D" 
        else:
            p+="d"
    elif k == 5:
        r=randint(1,2)
        if r == 1:
            p+="E" 
        else:
            p+="e"
    elif k == 6:
        r=randint(1,2)
        if r == 1:
            p+="F" 
        else:
            p+="f"
    elif k == 7:
        r=randint(1,2)
        if r == 1:
            p+="G" 
        else:
            p+="g" 
    elif k == 8:
        r=randint(1,2)
        if r == 1:
            p+="H" 
        else:
            p+="h" 
    elif k == 9:
        r=randint(1,2)
        if r == 1:
            p+="I" 
        else:
            p+="i" 
    elif k == 10:
        r=randint(1,2)
        if r == 1:
            p+="J" 
        else:
            p+="j" 
    elif k == 11:
        r=randint(1,2)
        if r == 1:
            p+="K" 
        else:
            p+="k"
    elif k == 12:
        r=randint(1,2)
        if r == 1:
            p+="L" 
        else:
            p+="l"
    elif k == 13:
        r=randint(1,2)
        if r == 1:
            p+="M" 
        else:
            p+="m"
    elif k == 14:
        r=randint(1,2)
        if r == 1:
            p+="N" 
        else:
            p+="n"
    elif k == 15:
        r=randint(1,2)
        if r == 1:
            p+="O" 
        else:
            p+="o"
    elif k == 16:
        r=randint(1,2)
        if r == 1:
            p+="P" 
        else:
            p+="p"
    elif k == 17:
        r=randint(1,2)
        if r == 1:
            p+="Q" 
        else:
            p+="q"
    elif k == 18:
        r=randint(1,2)
        if r == 1:
            p+="R" 
        else:
            p+="r"
    elif k == 19:
        r=randint(1,2)
        if r == 1:
            p+="S" 
        else:
            p+="s"
    elif k == 20:
        r=randint(1,2)
        if r == 1:
            p+="T" 
        else:
            p+="t"
    elif k == 21:
        r=randint(1,2)
        if r == 1:
            p+="U" 
        else:
            p+="u"
    elif k == 22:
        r=randint(1,2)
        if r == 1:
            p+="V" 
        else:
            p+="v"
    elif k == 23:
        r=randint(1,2)
        if r == 1:
            p+="W" 
        else:
            p+="w"
    elif k == 24:
        r=randint(1,2)
        if r == 1:
            p+="X" 
        else:
            p+="x"
    elif k == 25:
        r=randint(1,2)
        if r == 1:
            p+="Y" 
        else:
            p+="y"
    else:
        r=randint(1,2)
        if r == 1:
            p+="Z" 
        else:
            p+="z"
print("\r your password is ready : ",end="")
print(p)
pp=input()